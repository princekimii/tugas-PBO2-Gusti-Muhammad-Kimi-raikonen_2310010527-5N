/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo2_2310010527;
import frame.FrameMenu;
import configDB.kontak;

/**
 *
 * @author muham
 */
public class Pbo2_2310010527 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     //    kontak tes = new kontak();
          new FrameMenu().setVisible(true);
   //tes.Simpankontak ("zeb","gemink","yaa" , "kgk","kwksowk");
        //tes.ubahAnggota02("0102", "arya saputra", "jomblo", "082121212334");
        //tes.hapusAnggota02("ID01");
        // TODO code application logic here
    }
    
}
