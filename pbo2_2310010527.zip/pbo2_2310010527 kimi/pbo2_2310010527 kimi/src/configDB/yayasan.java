/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author muham
 */
public class yayasan {
     private String namaDB = "pbo2__2310010527";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection koneksi;
    public String VAR_NAMA_YAYASAN = null;
    public String VAR_ALAMAT = null;
    public String VAR_STATUS = null;
    public boolean validasi = false;
    
    public yayasan(){
        try {
           Driver mysqldriver = new com.mysql.jdbc.Driver();
           DriverManager.registerDriver(mysqldriver);
           koneksi = DriverManager.getConnection(url,username,password);
           System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
                
        }
    }
    
   
    // ================= SIMPAN DATA (VERSI PREPAREDSTATEMENT) =================
     public void Simpanyayasan(String npsn, String nama_yayasan, String alamat, String status){
        try {
            String sql = "insert into yayasan(npsn, nama_yayasan, alamat, status) value(?, ?, ?, ?)";
                String cekPrimary = "select * from yayasan where npsn= ?";
            
            PreparedStatement check = koneksi.prepareStatement(cekPrimary);
            check.setString(1, npsn);
            ResultSet data = check.executeQuery();
            if (data.next()){
                JOptionPane.showMessageDialog(null, "npsn sudah terdaftar");
                this.VAR_NAMA_YAYASAN = data.getString("Nama");
                this.VAR_ALAMAT = data.getString("alamat");
                this.VAR_STATUS = data.getString("status");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_YAYASAN = null;
                this.VAR_STATUS = null;
                this.VAR_STATUS = null;
                this.validasi = true;
                PreparedStatement perintah = koneksi.prepareStatement(sql);
                perintah.setString(1, npsn);
                perintah.setString(2, nama_yayasan);
                perintah.setString(3, alamat);
                perintah.setString(4, status);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "berhasil disimpan");
            }
            
    
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            
        }
    }
   
    public void ubahyayasan(String npsn, String nama_yayasan, String alamat, String status){
        try {
            String sql = "UPDATE yayasan SET nama_yayasan = ?, alamat = ?, status = ? WHERE npsn = ?";
            
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, nama_yayasan);
            perintah.setString(2, alamat);
            perintah.setString(3, status);
            perintah.setString(4, npsn);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mengubah: " + e.getMessage());
        }
    }
    
    
    // ================= HAPUS DATA (VERSI PREPAREDSTATEMENT) =================
    public void hapusYayasan(String npsn){
        try {
            String sql = "DELETE FROM yayasan WHERE npsn = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, npsn);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat menghapus: " + e.getMessage());
        }
    }
    
    // ================= CARI DATA =================
    public void tambahYayasan(String npsn){
        try {
            String sql = "SELECT * FROM Yayasan WHERE npsn = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, npsn);
            ResultSet hasil = perintah.executeQuery();
            
            if (hasil.next()){
                this.VAR_NAMA_YAYASAN = hasil.getString("nama_yayasan");
                this.VAR_ALAMAT = hasil.getString("alamat");
                this.VAR_STATUS = hasil.getString("status");
            } else {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mencari data: " + e.getMessage());
        }
    }
    public void tampilDatayayasan (JTable komponenTable, String SQL){
          try {
              Statement perintah = koneksi.createStatement();
              ResultSet data = perintah.executeQuery(SQL);
              ResultSetMetaData meta = data.getMetaData();
              int jumKolom = meta.getColumnCount();
              DefaultTableModel modelTable = new DefaultTableModel();
              modelTable.addColumn("NPSN");
              modelTable.addColumn("Nama Yayasam");
              modelTable.addColumn("Alamat");
              modelTable.addColumn("Status");
              modelTable.getDataVector().clear();
              modelTable.fireTableDataChanged();
              while (data.next() ) {
                  Object[] row = new Object[jumKolom];
                  for(int i = 1; i <= jumKolom; i++ ){
                      row [i - 1] = data.getObject(i);
                  }
                  modelTable.addRow(row);
              }
              komponenTable.setModel(modelTable);
          } catch (Exception e) {
              
          }
      }
    
    public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.koneksi);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
}

