/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;


/**
 *
 * @author muham
 */
public class jurusan {
   private String namaDB = "pbo2__2310010527";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection koneksi;
    
    public String VAR_ID_JURUSAN = null;
    public String VAR_NAMA_JURUSAN = null;
    public Integer VAR_KUOTA = null;
    public String VAR_STATUS = null;
    public boolean validasi = false;
    public String VAR_ID_JENIS; 
    
    public jurusan(){
        try {
           Driver mysqldriver = new com.mysql.jdbc.Driver();
           DriverManager.registerDriver(mysqldriver);
           koneksi = DriverManager.getConnection(url,username,password);
           System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
                
        }
    }
    
   
    // ================= SIMPAN DATA (VERSI PREPAREDSTATEMENT) =================
     public void Simpanjurusan(String id_jurusan,String id_jenis, String nama_jurusan, Integer kuota, String status){
        try {
            String sql = "insert into jurusan(id_jurusan, nama_jurusan, kuota, status) value(?, ?, ?, ?)";
                String cekPrimary = "select * from jurusan where id_jurusan= ?";
            
            PreparedStatement check = koneksi.prepareStatement(cekPrimary);
            check.setString(1, id_jurusan);
            ResultSet data = check.executeQuery();
            if (data.next()){
                JOptionPane.showMessageDialog(null, "id_jurusan sudah terdaftar");
                this.VAR_ID_JENIS = data.getString("id_jenis");
                this.VAR_NAMA_JURUSAN = data.getString("nama_jurusan");
                this.VAR_KUOTA = data.getInt("kuota");
                this.VAR_STATUS = data.getString("status");
                this.validasi = true;
            } else {
                PreparedStatement perintah = koneksi.prepareStatement(sql);
                perintah.setString(1, id_jurusan);
                perintah.setString(2, id_jenis);
                perintah.setString(3, nama_jurusan);
                perintah.setInt(4, kuota);
                perintah.setString(5, status);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "berhasil disimpan");
            }
            
    
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            
        }
    }
   
    public void ubahjurusan(String id_jurusan, String id_jenis, String nama_jurusan, Integer kuota, String status){
        try {
            String sql = "UPDATE jurusan SET id_jenis = ?, nama_jurusan = ?, kuota = ?, status = ? WHERE id_jurusan = ?";
            
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, id_jenis);
            perintah.setString(2, nama_jurusan);
            perintah.setInt(3,kuota );
            perintah.setString(4, status);
            perintah.setString(5, id_jurusan);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mengubah: " + e.getMessage());
        }
    }
    
    
    // ================= HAPUS DATA (VERSI PREPAREDSTATEMENT) =================
    public void hapusjurusan(String id_jurusan){
        try {
            String sql = "DELETE FROM yayasan WHERE npsn = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, id_jurusan);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat menghapus: " + e.getMessage());
        }
    }
    
 
   public void tambahjurusan(String id_jenis){
        try {
            String sql = "SELECT * FROM jenis WHERE id_jenis = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, id_jenis);
            ResultSet hasil = perintah.executeQuery();
            
            if (hasil.next()){
                this.VAR_ID_JENIS = hasil.getString("id_jenis");
                this.VAR_NAMA_JURUSAN = hasil.getString("nama_jurusan");
                this.VAR_KUOTA = hasil.getInt("kuota");
                this.VAR_STATUS = hasil.getString("status");
            } else {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mencari data: " + e.getMessage());
        }
    }
    
    public void tampilDatajurusan (JTable komponenTable, String SQL){
          try {
              Statement perintah = koneksi.createStatement();
              ResultSet data = perintah.executeQuery(SQL);
              ResultSetMetaData meta = data.getMetaData();
              int jumKolom = meta.getColumnCount();
              DefaultTableModel modelTable = new DefaultTableModel();
              modelTable.addColumn("ID Jurusan");
              modelTable.addColumn("Nama Jurusan");
              modelTable.addColumn("Kuota");
              modelTable.addColumn("Status");
              modelTable.getDataVector().clear();
              modelTable.fireTableDataChanged();
              while (data.next() ) {
                  Object[] row = new Object[jumKolom];
                  for(int i = 1; i <= jumKolom; i++ ){
                      row [i - 1] = data.getObject(i);
                  }
                  modelTable.addRow(row);
              }
              komponenTable.setModel(modelTable);
          } catch (Exception e) {
              
          }
      }
    
    public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.koneksi);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
}

 

