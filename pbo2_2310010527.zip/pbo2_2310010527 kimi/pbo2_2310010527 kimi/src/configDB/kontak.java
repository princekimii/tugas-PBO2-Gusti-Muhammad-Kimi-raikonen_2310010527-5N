/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author muham
 */
public class kontak {
   private final String namaDB = "pbo2__2310010527";
    private final String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private final String username = "root";
    private final String password = "";
    private Connection koneksi;

    // Variabel untuk menyimpan hasil query
    public String VAR_NPSN = null;
    public String VAR_NAMA_KONTAK = null;
    public String VAR_NO_KONTAK = null;
    public String VAR_STATUS = null;
    public boolean validasi = false;

     public kontak(){
        try {
           Driver mysqldriver = new com.mysql.jdbc.Driver();
           DriverManager.registerDriver(mysqldriver);
           koneksi = DriverManager.getConnection(url,username,password);
           System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
                
        }
    }

    // ======================= SIMPAN DATA =======================
    public void Simpankontak( String id_kontak,String npsn, String nama_kontak, String no_kontak, String status) {
        try {
            String sql = "INSERT INTO kontak (id_kontak, npsn, nama_kontak, no_kontak, status) VALUES (?, ?, ?, ?, ?)";
            String cekPrimary = "SELECT * FROM kontak WHERE id_kontak = ?";

            PreparedStatement check = koneksi.prepareStatement(cekPrimary);
            check.setString(1, id_kontak);
            ResultSet data = check.executeQuery();

            if (data.next()) {
                JOptionPane.showMessageDialog(null, "id_kontak sudah terdaftar di tabel kontak!");
                this.VAR_NPSN = data.getString("npsn");
                this.VAR_NAMA_KONTAK = data.getString("nama_kontak");
                this.VAR_NO_KONTAK = data.getString("no_kontak");
                this.VAR_STATUS = data.getString("status");
                this.validasi = true;
            } else {
                PreparedStatement perintah = koneksi.prepareStatement(sql);
                perintah.setString(1, id_kontak);
                perintah.setString(2, npsn);
                perintah.setString(3, nama_kontak);
                perintah.setString(4, no_kontak);
                perintah.setString(5, status);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data berhasil disimpan!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat menyimpan: " + e.getMessage());
        }
    }

    // ======================= UBAH DATA =======================
    public void ubahkontak(String id_kontak, String npsn, String nama_kontak, String no_kontak, String status) {
        try {
            String sql = "UPDATE kontak SET npsn = ?, nama_kontak = ?, no_kontak = ?, status = ? WHERE id_kontak = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, npsn);
            perintah.setString(2, nama_kontak);
            perintah.setString(3, no_kontak);
            perintah.setString(4, status);
            perintah.setString(5, id_kontak);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mengubah data: " + e.getMessage());
        }
    }

    // ======================= HAPUS DATA =======================
    public void hapuskontak(String id_kontak) {
        try {
            String sql = "DELETE FROM kontak WHERE id_kontak = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, id_kontak);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat menghapus data: " + e.getMessage());
        }
    }

    // ======================= CARI DATA =======================
    public void tambahkontak(String id_kontak){
        try {
            String sql = "SELECT * FROM kontak WHERE id_kontak = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, id_kontak);
            ResultSet hasil = perintah.executeQuery();
            
            if (hasil.next()){
                this.VAR_NPSN = hasil.getString("npsn");
                this.VAR_NAMA_KONTAK = hasil.getString("nama_kontak");
                this.VAR_NO_KONTAK = hasil.getString("no_kontak");
                this.VAR_STATUS = hasil.getString("status");
            } else {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mencari data: " + e.getMessage());
        }
    }
    public void tampilDatakontak (JTable komponenTable, String SQL){
          try {
              Statement perintah = koneksi.createStatement();
              ResultSet data = perintah.executeQuery(SQL);
              ResultSetMetaData meta = data.getMetaData();
              int jumKolom = meta.getColumnCount();
              DefaultTableModel modelTable = new DefaultTableModel();
              modelTable.addColumn("NPSN");
              modelTable.addColumn("Nama Kontak");
              modelTable.addColumn("No Kontak");
              modelTable.addColumn("Status");
              modelTable.getDataVector().clear();
              modelTable.fireTableDataChanged();
              while (data.next() ) {
                  Object[] row = new Object[jumKolom];
                  for(int i = 1; i <= jumKolom; i++ ){
                      row [i - 1] = data.getObject(i);
                  }
                  modelTable.addRow(row);
              }
              komponenTable.setModel(modelTable);
          } catch (Exception e) {
              
          }
      }
    
      public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.koneksi);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
    }
