/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author muham
 */
public class jenis {
    private String namaDB = "pbo2__2310010527";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection koneksi;
    
    public String VAR_ID_JENIS = null;
    public String VAR_NAMA_JENIS = null;
    public Integer VAR_KUOTA = null;
    public String VAR_STATUS = null;
    public boolean validasi = false;
    
    public jenis(){
        try {
           Driver mysqldriver = new com.mysql.jdbc.Driver();
           DriverManager.registerDriver(mysqldriver);
           koneksi = DriverManager.getConnection(url,username,password);
           System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
                
        }
    }
    
   
    // ================= SIMPAN DATA (VERSI PREPAREDSTATEMENT) =================
     public void Simpanjenis(String id_jenis, String nama_jenis, Integer kuota, String status){
        try {
            String sql = "insert into jenis(id_jenis, nama_jenis, kuota, status) value(?, ?, ?, ?)";
                String cekPrimary = "select * from jenis where id_jenis= ?";
            
            PreparedStatement check = koneksi.prepareStatement(cekPrimary);
            check.setString(1, id_jenis);
            ResultSet data = check.executeQuery();
            if (data.next()){
                JOptionPane.showMessageDialog(null, "id_jenis sudah terdaftar");
                this.VAR_NAMA_JENIS = data.getString("Nama");
                this.VAR_KUOTA = data.getInt("kuota");
                this.VAR_STATUS = data.getString("status");
                this.validasi = true;
            } else {
                PreparedStatement perintah = koneksi.prepareStatement(sql);
                perintah.setString(1, id_jenis);
                perintah.setString(2, nama_jenis);
                perintah.setInt(3, kuota);
                perintah.setString(4, status);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "berhasil disimpan");
            }
            
    
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            
        }
    }
   
    public void ubahjenis(String id_jenis, String nama_jenis, Integer kuota, String status){
        try {
            String sql = "UPDATE jenis SET nama_jenis = ?, kuota = ?, status = ? WHERE id_jenis = ?";
            
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, nama_jenis);
            perintah.setInt(2, kuota);
            perintah.setString(3, status);
            perintah.setString(4, id_jenis);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mengubah: " + e.getMessage());
        }
    }
    
    
    // ================= HAPUS DATA (VERSI PREPAREDSTATEMENT) =================
    public void hapusjenis(String id_jenis){
        try {
            String sql = "DELETE FROM yayasan WHERE id_jenis = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, id_jenis);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat menghapus: " + e.getMessage());
        }
    }
    
    // ================= CARI DATA =================
   public void tambahjenis(String id_jenis){
        try {
            String sql = "SELECT * FROM jenis WHERE id_jenis = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, id_jenis);
            ResultSet hasil = perintah.executeQuery();
            
            if (hasil.next()){
                this.VAR_NAMA_JENIS = hasil.getString("nama_jenis");
                this.VAR_KUOTA = hasil.getInt("kuota");
                this.VAR_STATUS = hasil.getString("status");
            } else {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Kesalahan saat mencari data: " + e.getMessage());
        }
    }
   public void tampilDatajenis (JTable komponenTable, String SQL){
          try {
              Statement perintah = koneksi.createStatement();
              ResultSet data = perintah.executeQuery(SQL);
              ResultSetMetaData meta = data.getMetaData();
              int jumKolom = meta.getColumnCount();
              DefaultTableModel modelTable = new DefaultTableModel();
              modelTable.addColumn("ID Jenis");
              modelTable.addColumn("Nama Jenis");
              modelTable.addColumn("Kuota");
              modelTable.addColumn("Status");
              modelTable.getDataVector().clear();
              modelTable.fireTableDataChanged();
              while (data.next() ) {
                  Object[] row = new Object[jumKolom];
                  for(int i = 1; i <= jumKolom; i++ ){
                      row [i - 1] = data.getObject(i);
                  }
                  modelTable.addRow(row);
              }
              komponenTable.setModel(modelTable);
          } catch (Exception e) {
              
          }
      }
   
   public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.koneksi);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
}
    




